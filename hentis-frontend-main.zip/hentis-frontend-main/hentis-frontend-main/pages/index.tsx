import Home from "../app/views/Home";

import "swiper/css";
import "swiper/css/effect-coverflow";
import "swiper/css/navigation";

export default Home;
