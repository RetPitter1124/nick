export class CreateBidDto {}
