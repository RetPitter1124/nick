export class CreateItemAttributeDto {}
