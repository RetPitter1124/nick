import {
  Box,
  HStack,
  Icon,
  Input,
  StackItem,
  Text,
  useColorModeValue,
  VStack,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { Currency, CurrencyAmount, Percent, Token } from "hentis-sdk-core";
import { Pair } from "hentis-v2-sdk";
import { ReactNode } from "react";
import { RiWallet3Line } from "react-icons/ri";
import CurrencySelect from "../CurrencySelect/CurrencySelect";
interface SwapCurrencyInputProps {
  value?: string;
  onUserInput?: (value: string) => void;
  onMax?: () => void;
  showMaxButton?: boolean;
  label?: ReactNode;
  onCurrencySelect?: (currency: Currency) => void;
  currency?: Currency | null;
  hideBalance?: boolean;
  pair?: Pair | null;
  hideInput?: boolean;
  otherCurrency?: Currency | null;
  fiatValue?: CurrencyAmount<Token> | null;
  priceImpact?: Percent;
  id?: string;
  showCommonBases?: boolean;
  showCurrencyAmount?: boolean;
  disableNonToken?: boolean;
  renderBalance?: (amount: CurrencyAmount<Currency>) => ReactNode;
  locked?: boolean;
  loading?: boolean;
}

const SwapCurrencyInput = ({
  showMaxButton = false,
  label = "",
}: SwapCurrencyInputProps) => {
  const { i18n } = useLingui();
  return (
    <VStack
      bgColor={useColorModeValue("gray.50", "gray.800")}
      p={{ base: "3" }}
      fontSize={{ base: "sm" }}
      borderRadius="9"
    >
      <HStack justifyContent={"space-between"} width="100%">
        <StackItem>
          <Text>{label}</Text>
        </StackItem>
        <StackItem verticalAlign={"center"}>
          <HStack>
            <Icon as={RiWallet3Line} fontSize={{ base: "xl", md: "xl" }} />
            <Text display={"inline"}>0.00</Text>
            <Box
              cursor={showMaxButton ? "pointer" : "initial"}
              px={2}
              py="0"
              display="inline"
              textTransform="uppercase"
              bgColor="transparent"
              color="blue.500"
              _hover={{ color: "blue.600" }}
              _active={{ color: "blue.700" }}
              transition={"color .3s"}
              lineHeight={1}
              opacity={showMaxButton ? 1 : 0}
            >
              {i18n._(t({ message: "MAX" }))}
            </Box>
          </HStack>
        </StackItem>
      </HStack>
      <HStack
        justifyContent={"space-between"}
        width="100%"
        alignItems={"flex-start"}
      >
        <StackItem flex="1">
          <Input
            type={"number"}
            border="0"
            padding="0"
            fontWeight={"bold"}
            placeholder="0.00"
            _focusVisible={{ border: "0", outline: "none" }}
            fontSize={{ base: "xl" }}
          />
          <Text>$3.54</Text>
        </StackItem>
        <StackItem>
          <CurrencySelect />
        </StackItem>
      </HStack>
    </VStack>
  );
};

export default SwapCurrencyInput;
