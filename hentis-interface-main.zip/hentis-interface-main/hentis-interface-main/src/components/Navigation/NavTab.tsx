import {
  HStack,
  Link,
  List,
  ListItem,
  StackItem,
  useColorModeValue,
} from "@chakra-ui/react";
import NextLink from "next/link";
import { useRouter } from "next/router";
import { ReactNode } from "react";

export interface NavTabItemData {
  href: string;
  isExternal?: boolean;
  icon?: ReactNode;
  text?: ReactNode;
}

const NavTab = ({ data }: { data: NavTabItemData[] }) => {
  const router = useRouter();
  const navColor = useColorModeValue("black", "white");
  return (
    <HStack
      as={List}
      width="100%"
      border="1px"
      p={{ base: "1", lg: "2" }}
      borderRadius={"7"}
      borderColor={useColorModeValue("black", "gray.500")}
      bgColor={useColorModeValue("gray.50", "gray.800")}
    >
      {data.map((item, index) => {
        const isActive = item.href.indexOf(router.pathname) === 0;
        return (
          <StackItem as={ListItem} key={index} flex="1">
            <NextLink href={item.href} passHref>
              <Link
                isExternal={item.isExternal}
                display="block"
                fontWeight={"semibold"}
                textAlign={"center"}
                p={{ base: "0.5", lg: "1" }}
                fontSize={{ base: "lg", md: "xl", lg: "2xl" }}
                borderRadius="7"
                color={isActive ? "white" : navColor}
                transition="background-color .3s"
                _hover={{
                  color: isActive ? "white" : navColor,
                  bgColor: isActive ? "blue.600" : "blackAlpha.300",
                }}
                bgColor={isActive ? "blue.500" : "transparent"}
              >
                {item.icon}
                {item.text}
              </Link>
            </NextLink>
          </StackItem>
        );
      })}
    </HStack>
  );
};

export default NavTab;
