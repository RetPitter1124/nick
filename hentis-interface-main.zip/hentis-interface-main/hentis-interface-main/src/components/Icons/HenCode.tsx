import { Icon, IconProps } from "@chakra-ui/react";

export const HenCode = (props: IconProps) => {
  return (
    <Icon viewBox="0 0 54 32" {...props}>
      <path
        d="M20.0667 28.2667L7.8 16L20.0667 3.73333L16.3333 0L0.333332 16L16.3333 32L20.0667 28.2667ZM33.9333 28.2667L46.2 16L33.9333 3.73333L37.6667 0L53.6667 16L37.6667 32L33.9333 28.2667Z"
        fill="white"
      />
    </Icon>
  );
};
