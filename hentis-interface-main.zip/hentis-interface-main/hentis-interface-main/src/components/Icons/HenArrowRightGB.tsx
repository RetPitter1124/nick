import { Icon, IconProps } from "@chakra-ui/react";

export const HenArrowRightGB = (props: IconProps) => {
  return (
    <Icon viewBox="0 0 43 22" {...props}>
      <path
        d="M32.0267 8H0V13.3333H32.0267V21.3333L42.6667 10.6667L32.0267 0V8Z"
        fill="url(#paint0_linear_121_2)"
      />
      <defs>
        <linearGradient
          id="paint0_linear_121_2"
          x1="0"
          y1="11"
          x2="43"
          y2="11"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#ffffff" />
          <stop offset="1" stopColor="#ffffff" />
        </linearGradient>
      </defs>
    </Icon>
  );
};
