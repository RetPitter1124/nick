import { useColorMode } from "@chakra-ui/react";
import { HiOutlineMoon, HiOutlineSun } from "react-icons/hi";
import SwitchGroup from "./SwitchGroup";

const ColorModeSwitch = () => {
  const { colorMode, setColorMode } = useColorMode();
  return (
    <SwitchGroup
      value={colorMode}
      onChange={setColorMode}
      list={[
        {
          value: "dark",
          text: <HiOutlineMoon fontSize={"20px"} />,
        },
        {
          value: "light",
          text: <HiOutlineSun fontSize={"20px"} />,
        },
      ]}
    />
  );
};

export default ColorModeSwitch;
