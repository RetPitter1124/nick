import {
  Box,
  chakra,
  HStack,
  RadioProps,
  useColorModeValue,
  useRadio,
  useRadioGroup,
} from "@chakra-ui/react";
import { ReactNode } from "react";
const SwitchItem = (props: RadioProps) => {
  const { children, ...radioProps } = props;
  const { state, getInputProps, getCheckboxProps, htmlProps, getLabelProps } =
    useRadio(radioProps);
  const boxColor = useColorModeValue("black", "white");

  return (
    <chakra.label {...htmlProps} cursor="pointer">
      <input {...getInputProps({})} hidden />
      <Box
        {...getCheckboxProps()}
        bg={state.isChecked ? "black" : "transparent"}
        color={state.isChecked ? "white" : boxColor}
        px={"2"}
        py={"1"}
        rounded="5"
      >
        {children}
      </Box>
    </chakra.label>
  );
};

const SwitchGroup = ({
  value,
  onChange = () => {},
  list = [],
}: {
  value: string;
  onChange?: (value: string) => void;
  list?: { value: string; text: ReactNode }[];
}) => {
  const { getRadioProps, getRootProps } = useRadioGroup({
    value,
    onChange,
  });
  return (
    <HStack
      cursor="pointer"
      p={{ base: "1", md: "2" }}
      borderRadius={"7"}
      bgColor={useColorModeValue("white", "gray.800")}
      {...getRootProps}
    >
      {list.map((item) => {
        return (
          <SwitchItem
            key={item.value}
            {...getRadioProps({ value: item.value })}
          >
            {item.text}
          </SwitchItem>
        );
      })}
    </HStack>
  );
};

export default SwitchGroup;
