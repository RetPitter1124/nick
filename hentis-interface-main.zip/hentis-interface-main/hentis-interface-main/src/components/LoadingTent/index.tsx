import {
  chakra,
  Box,
  Image,
  shouldForwardProp,
  Container,
} from "@chakra-ui/react";
import { motion, isValidMotionProp } from "framer-motion";

import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";

const ChakraBox = chakra(motion.div, {
  shouldForwardProp: (prop) =>
    isValidMotionProp(prop) || shouldForwardProp(prop),
});

const LoadingTent = () => {
  return (
    <Container
      h="100vh"
      display="flex"
      alignItems="center"
      justifyContent="center"
    >
      <ChakraBox
        animate={{
          scale: [1, 1.5, 1.5, 1, 1],
          rotate: [0, 1080, 1440],
        }}
        // @ts-ignore
        transition={{
          duration: 3,
          ease: "easeInOut",
          repeat: Infinity,
          repeatType: "loop",
        }}
        padding="2"
        display="flex"
        justifyContent="center"
        alignItems="center"
        width="75px"
        height="75px"
      >
        <Image src="/apple-touch-icon.png" alt={""} />
      </ChakraBox>
    </Container>
  );
};

export default LoadingTent;
