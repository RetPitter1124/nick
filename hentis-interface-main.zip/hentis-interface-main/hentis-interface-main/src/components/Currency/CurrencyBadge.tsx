import { Avatar, HStack, Text, useColorModeValue } from "@chakra-ui/react";

const CurrencyBadge = () => {
  return (
    <HStack
      bgColor={useColorModeValue("white", "gray.800")}
      p={{ base: "1.5", md: "2.5" }}
      py={{ base: "1.5", md: "2.5" }}
      borderRadius={"7"}
    >
      <Avatar size="xs" name="Hentis" src="/apple-touch-icon.png" />
      <Text fontWeight={"semibold"}>$5.24</Text>
    </HStack>
  );
};

export default CurrencyBadge;
