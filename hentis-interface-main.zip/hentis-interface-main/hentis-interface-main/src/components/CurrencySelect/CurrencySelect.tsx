import {
  Avatar,
  HStack,
  Icon,
  Text,
  useColorModeValue,
  useDisclosure,
} from "@chakra-ui/react";
import { Currency } from "hentis-sdk-core";
import { HiOutlineChevronDown } from "react-icons/hi";
import CurrencySelectModal from "./CurrencySelectModal";

export interface CurrencySelectProps {
  onChangeCurrency: (currency: Currency) => void;
}

const CurrencySelect = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  return (
    <HStack
      cursor={"pointer"}
      p={{ base: "2" }}
      borderRadius={"10"}
      bgColor={useColorModeValue("white", "gray.900")}
      color={useColorModeValue("black", "white")}
      onClick={onOpen}
    >
      <Avatar src="/apple-touch-icon.png" name="HEN" size={"xs"} />
      <Text fontSize={{ base: "lg" }} fontWeight="bold">
        HEN
      </Text>
      <Icon as={HiOutlineChevronDown} fontSize={{ base: "md" }} />
      <CurrencySelectModal isOpen={isOpen} onClose={onClose} />
    </HStack>
  );
};

export default CurrencySelect;
