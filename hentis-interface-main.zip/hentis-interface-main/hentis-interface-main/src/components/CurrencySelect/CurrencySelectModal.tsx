import {
  HStack,
  Icon,
  IconButton,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { Currency } from "hentis-sdk-core";
import { HiOutlineArrowLeft } from "react-icons/hi";

interface CurrencySelectModalProps {
  isOpen?: boolean;
  onClose: () => void;
  onSelectCurrency?: (currency: Currency) => void;
}

const CurrencySelectModal = ({
  isOpen = false,
  onClose,
  onSelectCurrency = () => {},
}: CurrencySelectModalProps) => {
  const { i18n } = useLingui();

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size="lg">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            <HStack mx="-4">
              <IconButton
                onClick={onClose}
                bgColor="transparent"
                icon={<Icon as={HiOutlineArrowLeft} fontSize="2xl" />}
                aria-label=""
                borderRadius={"full"}
              />
              <Text fontSize={"lg"}>
                {i18n._(t({ message: "Select a token" }))}
              </Text>
            </HStack>
          </ModalHeader>
          <ModalBody></ModalBody>
          <ModalFooter></ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default CurrencySelectModal;
