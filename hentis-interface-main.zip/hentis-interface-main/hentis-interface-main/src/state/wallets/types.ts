export interface Wallet {
  walletType: string;
  account: string;
}
