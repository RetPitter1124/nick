import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import {
  FLUSH,
  PAUSE,
  PERSIST,
  persistReducer,
  PURGE,
  REGISTER,
  REHYDRATE,
} from "redux-persist";
import storage from "redux-persist/lib/storage";
import wallets from "./wallets/reducer";
import counter from "./counter/reducer";
import global from "./global/reducer";

const persistConfig = {
  key: "root",
  storage,
  whitelist: ["wallets", "counter"], // place to select which state you want to persist
  timeout: 1000,
};

const rootReducer = persistReducer(
  persistConfig,
  combineReducers({
    wallets,
    counter,
    global,
  })
);

const createStore = () => {
  return configureStore({
    reducer: rootReducer,
    middleware: (getDefaultMiddleware) => [
      ...getDefaultMiddleware({
        serializableCheck: {
          ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
        },
      }),
    ],
  });
};

const store = createStore();
export default store;

export type AppState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
