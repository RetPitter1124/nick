import { useCallback } from "react";
import { useAppDispatch, useAppSelector } from "../hooks";

import { disableComingSoon, enableComingSoon } from "./reducer";

export function useComingSoon(): [boolean, () => void, () => void] {
  const dispatch = useAppDispatch();
  const isComingSoon = useAppSelector((state) => state.global.isComingSoon);
  const enableComingSoonHook = useCallback(() => {
    dispatch(enableComingSoon());
  }, [dispatch]);
  const disableComingSoonDispatch = useCallback(() => {
    dispatch(disableComingSoon());
  }, [dispatch]);
  return [isComingSoon, enableComingSoonHook, disableComingSoonDispatch];
}
