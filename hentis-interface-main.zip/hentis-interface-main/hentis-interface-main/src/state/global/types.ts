export interface Global {
  isComingSoon: boolean;
}
