import { createSlice } from "@reduxjs/toolkit";

import { Global } from "./types";

export const initialState: Global = {
  isComingSoon: false,
};

const comingSoonSlice = createSlice({
  name: "comingSoon",
  initialState,
  reducers: {
    enableComingSoon(state) {
      state.isComingSoon = true;
    },
    disableComingSoon(state) {
      state.isComingSoon = false;
    },
  },
});

export const { enableComingSoon, disableComingSoon } = comingSoonSlice.actions;
export default comingSoonSlice.reducer;
