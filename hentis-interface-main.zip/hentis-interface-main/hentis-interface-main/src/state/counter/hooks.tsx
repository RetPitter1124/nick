import { useCallback } from "react";
import { useAppDispatch, useAppSelector } from "../hooks";

import { decrement, increment } from "./reducer";

export function useCounter(): [number, () => void, () => void] {
  const dispatch = useAppDispatch();
  const count = useAppSelector((state) => state.counter.count);
  const incrementCounter = useCallback(() => {
    dispatch(increment());
  }, [dispatch]);
  const decrementCounter = useCallback(() => {
    dispatch(decrement());
  }, [dispatch]);
  return [count, incrementCounter, decrementCounter];
}
