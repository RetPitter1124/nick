export interface Counter {
  count: number;
}
