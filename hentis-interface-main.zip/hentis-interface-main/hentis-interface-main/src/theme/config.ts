const config = {
  cssVarPrefix: "hen",
  initialColorMode: "dark",
  useSystemColorMode: false,
};

export default config;
