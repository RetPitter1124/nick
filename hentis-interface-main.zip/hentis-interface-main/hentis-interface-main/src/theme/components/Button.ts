import { ComponentStyleConfig } from "@chakra-ui/react";

const Button: ComponentStyleConfig = {
  // The styles all button have in common
  baseStyle: {
    fontWeight: "semibold",
  },
  // Two sizes: sm and md
  sizes: {
    sm: {
      fontSize: "sm",
      px: 4, // <-- px is short for paddingLeft and paddingRight
      py: 3, // <-- py is short for paddingTop and paddingBottom
    },
    md: {
      fontSize: "md",
      px: 6, // <-- these values are tokens from the design system
      py: 4, // <-- these values are tokens from the design system
    },
    xl: {
      fontSize: "2xl",
      borderRadius: "9",
      px: 9,
      py: 5,
    },
  },
  variants: {
    gradient: (props) => {
      const { colorScheme } = props;
      switch (colorScheme) {
        case "secondary": {
          return {
            bgGradient: "linear(to-r, #bdb8f2 0.16%, #f6c2fa 96.22% 76.63%)",
            _hover: {
              bgGradient: "linear(to-r, #ada8e2 0.16%, #e6b2ea 96.22% 76.63%)",
            },
            _active: {
              bgGradient: "linear(to-r, #9d98d2 0.16%, #d6a2da 96.22% 76.63%)",
            },
            color: "blue.500",
          };
        }
        case "white": {
          return {
            background:
              "linear-gradient(#fff 0 0) padding-box, linear-gradient(to right, rgb(35, 20, 212), rgb(225, 53, 240)) border-box",
            border: "2px solid transparent",
            borderRadius: "7px",
            _hover: {
              background:
                "linear-gradient(#e6e2ef 0 0) padding-box, linear-gradient(to right, rgb(35, 20, 212), rgb(225, 53, 240)) border-box;",
            },
            _active: {
              background:
                "linear-gradient(#e6e2ef 0 0) padding-box, linear-gradient(to right, rgb(35, 20, 212), rgb(225, 53, 240)) border-box;",
            },
            color: "black",
          };
        }
        case "brand":
        default: {
          return {
            bgGradient: "linear(to-r, #2314D4, #E135F0 76.63%)",
            _hover: {
              bgGradient: "linear(to-r, #1304c4, #d125e0 76.63%)",
            },
            _active: {
              bgGradient: "linear(to-r, #0200a4, #c115d0 76.63%)",
            },
            color: "white",
          };
        }
      }
    },
  },
  // The default size and variant values
  defaultProps: {
    size: "md",
    variant: "solid",
  },
};

export default Button;
