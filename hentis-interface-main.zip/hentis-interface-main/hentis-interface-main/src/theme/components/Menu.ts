import { ComponentStyleConfig } from "@chakra-ui/react";
import { mode } from "@chakra-ui/theme-tools";

const Menu: ComponentStyleConfig = {
  baseStyle: (props: any) => {
    return {
      list: {
        bgColor: mode("gray.50", "gray.800")(props),
        borderColor: mode("gray.300", "gray.700")(props),
      },
    };
  },
};

export default Menu;
