import { ComponentStyleConfig, LinkProps } from "@chakra-ui/react";
import { mode } from "@chakra-ui/theme-tools";

const Link: ComponentStyleConfig = {
  baseStyle: (props: LinkProps) => {
    return {
      transition: "color .3s",
      _hover: {
        textDecor: "none",
        color: mode("gray.800", "gray.200")(props),
      },
    };
  },
};

export default Link;
