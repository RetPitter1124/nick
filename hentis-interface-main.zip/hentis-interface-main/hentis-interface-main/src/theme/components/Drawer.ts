import { ComponentStyleConfig, DrawerProps } from "@chakra-ui/react";
import { mode } from "@chakra-ui/theme-tools";

const Drawer: ComponentStyleConfig = {
  baseStyle: (props: any) => {
    return {
      dialog: {
        bg: mode("gray.50", "gray.800")(props),
      },
    };
  },
};

export default Drawer;
