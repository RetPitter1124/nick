const sizes = {
  7.5: "1.875rem",
};

export default sizes;
