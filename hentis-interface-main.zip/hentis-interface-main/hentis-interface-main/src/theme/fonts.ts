const fonts = {
  body: "Inter, -apple-system, Helvetica, Arial, sans-serif",
  heading: "Inter, -apple-system, Helvetica, Arial, sans-serif",
  mono: "Inter, -apple-system, Helvetica, Arial, sans-serif",
};

export default fonts;
