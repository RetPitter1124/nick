import { extendTheme } from "@chakra-ui/react";
import colors from "./colors";
import config from "./config";
import Button from "./components/Button";
import Drawer from "./components/Drawer";
import Input from "./components/Input";
import Link from "./components/Link";
import Menu from "./components/Menu";
import fonts from "./fonts";
import semanticTokens from "./semantic-tokens";
import sizes from "./sizes";
import styles from "./styles";

const overrides = {
  colors,
  config,
  fonts,
  components: {
    Button,
    Drawer,
    Input,
    Link,
    Menu,
  },
  semanticTokens,
  sizes,
  space: sizes,
  styles,
};
const theme = extendTheme(overrides);
export default theme;
