const semanticTokens = {
  colors: {
    "chakra-body-text": { _light: "black", _dark: "white" },
    "chakra-body-bg": { _light: "gray.50", _dark: "gray.800" },
    "chakra-border-color": { _light: "black", _dark: "gray.200" },
    "chakra-placeholder-color": { _light: "gray.500", _dark: "whiteAlpha.400" },
  },
};

export default semanticTokens;
