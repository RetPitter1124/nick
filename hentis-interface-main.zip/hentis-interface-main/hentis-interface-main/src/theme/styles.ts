import { StyleFunctionProps } from "@chakra-ui/theme-tools";
const styles = {
  global: (props: StyleFunctionProps) => {
    return {
      html: {
        overflowX: "hidden",
      },
      body: {
        overflowX: "hidden",
      },
    };
  },
};

export default styles;
