import AddLiquidity from "../views/AddLiquidity";

export default AddLiquidity;
