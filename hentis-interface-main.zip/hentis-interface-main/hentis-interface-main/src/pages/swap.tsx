import Swap from "../views/Swap";

export default Swap;
