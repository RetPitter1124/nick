import Home from "../views/Home";

export default Home;
