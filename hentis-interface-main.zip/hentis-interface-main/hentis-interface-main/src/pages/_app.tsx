import { ChakraProvider } from "@chakra-ui/react";
import { i18n } from "@lingui/core";
import { I18nProvider } from "@lingui/react";
import type { AppProps } from "next/app";
import { useRouter } from "next/router";
import { useEffect } from "react";
import { Provider } from "react-redux";
import { persistStore } from "redux-persist";
import { PersistGate } from "redux-persist/integration/react";
import LoadingTent from "../components/LoadingTent";
import { activate } from "../lingui/i18n";
import store from "../state";
import theme from "../theme";

function MyApp({ Component, pageProps }: AppProps) {
  const { locale } = useRouter();
  const persistor = persistStore(store);

  useEffect(() => {
    activate(locale || "en");
  }, [locale]);

  return (
    <I18nProvider i18n={i18n}>
      <ChakraProvider theme={theme}>
        <Provider store={store}>
          <PersistGate persistor={persistor} loading={<LoadingTent />}>
            <Component {...pageProps} />
          </PersistGate>
        </Provider>
      </ChakraProvider>
    </I18nProvider>
  );
}

export default MyApp;
