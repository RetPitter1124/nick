import {
  Center,
  Icon,
  IconButton,
  LightMode,
  StackItem,
  VStack,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { HiOutlinePlus } from "react-icons/hi";
import SwapCurrencyInput from "../../components/CurrencyInput/SwapCurrencyInput";

const LiquidityBox = ({}: {}) => {
  const { i18n } = useLingui();
  return (
    <VStack borderRadius={{ base: "10", md: "14" }}>
      <StackItem width="100%">
        <SwapCurrencyInput label={i18n._(t({ message: "Input" }))} />
      </StackItem>
      <StackItem position={"relative"} width="100%">
        <LightMode>
          <Center>
            <IconButton
              rounded={"full"}
              width={{ base: "10" }}
              height={{ base: "10" }}
              padding={0}
              aria-label={i18n._(t({ message: "Price" }))}
              variant={"gradient"}
              colorScheme="brand"
              icon={<Icon as={HiOutlinePlus} fontSize={{ base: "2xl" }} />}
            />
          </Center>
        </LightMode>
      </StackItem>
      <StackItem width="100%" pb={{ base: "4", md: "6" }}>
        <SwapCurrencyInput label={i18n._(t({ message: "Input" }))} />
      </StackItem>
    </VStack>
  );
};

export default LiquidityBox;
