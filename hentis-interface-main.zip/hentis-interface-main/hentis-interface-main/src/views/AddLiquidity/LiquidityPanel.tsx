import {
  Button,
  HStack,
  Icon,
  IconButton,
  LightMode,
  StackItem,
  Text,
  useColorModeValue,
  VStack,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { MdRefresh } from "react-icons/md";
import { HenSlide } from "../../components/Icons/HenSlide";
import LiquidityBox from "./LiquidityBox";
import LiquidityInfo from "./LiquidityInfo";

const LiquidityPanel = () => {
  const { i18n } = useLingui();
  return (
    <VStack
      bgColor={useColorModeValue("white", "gray.900")}
      p={{ base: "3", md: "6" }}
      fontSize={{ base: "md" }}
      fontWeight="medium"
      borderRadius={{ base: "12", md: "20" }}
    >
      <StackItem width="100%" textAlign={"right"}>
        <HStack justifyContent={"space-between"}>
          <Text fontWeight={"bold"}>
            {i18n._(t({ message: "Add Liquidity" }))}
          </Text>
          <HStack spacing="0">
            <IconButton
              bgColor={"transparent"}
              aria-label=""
              icon={<Icon as={MdRefresh} fontSize="2xl" />}
              borderRadius="full"
            />
            <Button
              bgColor={"transparent"}
              px="4"
              leftIcon={<HenSlide fontSize="xl" />}
              borderRadius="full"
            >
              0.5
            </Button>
          </HStack>
        </HStack>
      </StackItem>

      <StackItem width="100%" pb="6">
        <LiquidityBox />
      </StackItem>

      <StackItem width="100%" pb="6">
        <LiquidityInfo />
      </StackItem>

      <StackItem width={"100%"}>
        <LightMode>
          <Button
            variant="gradient"
            colorScheme={"secondary"}
            size={{ base: "lg", lg: "xl" }}
            display={"block"}
            w="100%"
          >
            {i18n._(t({ message: "Connect Wallet" }))}
          </Button>
        </LightMode>
      </StackItem>
    </VStack>
  );
};

export default LiquidityPanel;
