import { useColorModeValue, VStack } from "@chakra-ui/react";
import { useLingui } from "@lingui/react";
const LiquidityInfo = ({}: {}) => {
  const { i18n } = useLingui();
  return (
    <VStack
      bgColor={useColorModeValue("gray.50", "gray.800")}
      borderRadius={{ base: "10", md: "14" }}
    ></VStack>
  );
};

export default LiquidityInfo;
