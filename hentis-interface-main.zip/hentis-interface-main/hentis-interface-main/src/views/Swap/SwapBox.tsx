import {
  Center,
  Icon,
  IconButton,
  LightMode,
  StackItem,
  VStack,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { RiArrowUpDownFill } from "react-icons/ri";
import SwapCurrencyInput from "../../components/CurrencyInput/SwapCurrencyInput";

const SwapBox = ({}: {}) => {
  const { i18n } = useLingui();
  return (
    <VStack borderRadius={{ base: "10", md: "14" }}>
      <StackItem width="100%">
        <SwapCurrencyInput
          label={i18n._(t({ message: "From" }))}
          showMaxButton
        />
      </StackItem>
      <StackItem position={"relative"} width="100%">
        <LightMode>
          <Center>
            <IconButton
              rounded={"full"}
              width={{ base: "10" }}
              height={{ base: "10" }}
              padding={0}
              aria-label={i18n._(t({ message: "Price" }))}
              variant={"gradient"}
              colorScheme="brand"
              icon={<Icon as={RiArrowUpDownFill} fontSize={{ base: "2xl" }} />}
            />
          </Center>
        </LightMode>
      </StackItem>
      <StackItem width="100%" pb={{ base: "4", md: "6" }}>
        <SwapCurrencyInput label={i18n._(t({ message: "To (Estimate)" }))} />
      </StackItem>
    </VStack>
  );
};

export default SwapBox;
