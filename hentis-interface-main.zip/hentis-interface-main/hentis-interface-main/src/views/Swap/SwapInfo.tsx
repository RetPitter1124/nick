import {
  Box,
  HStack,
  Icon,
  StackItem,
  Text,
  Tooltip,
  useColorModeValue,
  VStack,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { ReactNode } from "react";
import { HiOutlineQuestionMarkCircle } from "react-icons/hi";

const SwapInfoItem = ({
  text = "",
  value = "",
  tooltip = "",
}: {
  text?: ReactNode;
  value?: ReactNode;
  tooltip?: ReactNode;
}) => {
  return (
    <HStack justifyContent={"space-between"} alignItems="flex-start">
      <StackItem>
        <HStack spacing={"0"} alignItems="center">
          <StackItem>
            <Text>{text}</Text>
          </StackItem>
          <StackItem>
            <Tooltip label={tooltip}>
              <Box>
                <Icon as={HiOutlineQuestionMarkCircle} display="block" />
              </Box>
            </Tooltip>
          </StackItem>
        </HStack>
      </StackItem>
      <StackItem>
        <Text display={"inline"} textAlign="right">
          {value}
        </Text>
      </StackItem>
    </HStack>
  );
};

const SwapInfo = () => {
  const { i18n } = useLingui();
  return (
    <VStack
      bgColor={useColorModeValue("gray.50", "gray.800")}
      p={{ base: "3" }}
      borderRadius="9"
      fontSize="sm"
    >
      <StackItem width="100%">
        <SwapInfoItem
          text={i18n._(t({ message: "Minimum Receive" }))}
          value={"0.0032 HEN ($0.001)"}
          tooltip={i18n._(
            t({
              message:
                "Your transaction will revert if the price changes unfavorably by more than this percentage.",
            })
          )}
        />
      </StackItem>
      <StackItem width="100%">
        <SwapInfoItem
          text={i18n._(t({ message: "Price Impact" }))}
          value={"0.00%"}
          tooltip="Price Impact"
        />
      </StackItem>
      <StackItem width="100%">
        <SwapInfoItem
          text={i18n._(t({ message: "Est. Trade Fee" }))}
          value={"0.0032 SUI ($0.1)"}
          tooltip="Est. Trade Fee"
        />
      </StackItem>
      <StackItem width="100%">
        <SwapInfoItem
          text={i18n._(t({ message: "Est. Fee Discount" }))}
          value={"0.00%"}
          tooltip="Est. Fee Discount"
        />
      </StackItem>
    </VStack>
  );
};

export default SwapInfo;
