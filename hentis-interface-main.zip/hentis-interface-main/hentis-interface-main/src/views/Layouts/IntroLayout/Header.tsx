import {
  Box,
  Button,
  Container,
  HStack,
  Image,
  LightMode,
  Link,
  StackItem,
  useColorModeValue,
  useDisclosure,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import NextLink from "next/link";

import ColorModeSwitch from "../../../components/Switch/ColorModeSwitch";
import { useComingSoon } from "../../../state/global/hooks";

const Header = () => {
  const { i18n } = useLingui();
  const [isComingSoon, enableComingSoon] = useComingSoon();
  return (
    <Box
      py="14px"
      pos={"fixed"}
      left="0"
      top="0"
      w="100%"
      zIndex={"999"}
      bgGradient={useColorModeValue(
        "linear(to-r, rgba(233, 231,251), rgba(252, 235, 253))",
        "linear(to-r, gray.700, gray.900)"
      )}
    >
      <Container
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
          "2xl": "container.2xl",
        }}
      >
        <HStack
          justifyContent={"space-between"}
          spacing={{ base: "3", lg: "8" }}
        >
          <StackItem>
            <HStack spacing={{ base: "3", lg: "8" }}>
              <StackItem>
                <NextLink href={"/"} passHref>
                  <Link>
                    <Image
                      src={"/apple-touch-icon.png"}
                      w={{ base: "35px", md: "54px" }}
                      alt={i18n._(t({ message: "Hentis.One" }))}
                    />
                  </Link>
                </NextLink>
              </StackItem>
            </HStack>
          </StackItem>
          <StackItem>
            <HStack spacing={{ base: "3", lg: "8" }}>
              <StackItem display={{ base: "none", lg: "block" }}>
                <ColorModeSwitch />
              </StackItem>
              <StackItem>
                <LightMode>
                  {/* <NextLink href="/swap"> */}
                  <Button
                    variant={"gradient"}
                    colorScheme="brand"
                    size={{ base: "md", md: "lg" }}
                    color={"white"}
                    onClick={enableComingSoon}
                  >
                    {i18n._(
                      isComingSoon
                        ? t({ message: "Coming Soon" })
                        : t({ message: "Enter App" })
                    )}
                  </Button>
                  {/* </NextLink> */}
                </LightMode>
              </StackItem>
            </HStack>
          </StackItem>
        </HStack>
      </Container>
    </Box>
  );
};

export default Header;
