import {
  Box,
  Button,
  HStack,
  LightMode,
  StackItem,
  useColorModeValue,
  useDisclosure,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import NextLink from "next/link";
import ColorModeSwitch from "../../../components/Switch/ColorModeSwitch";
import { useComingSoon } from "../../../state/global/hooks";

const Bar = () => {
  const { i18n } = useLingui();
  const [isComingSoon, enableComingSoon] = useComingSoon();

  return (
    <Box
      pos={"fixed"}
      zIndex="1401"
      px="4"
      py="2"
      bottom="0"
      left="0"
      width="100%"
      bgGradient={useColorModeValue(
        "linear(to-r, rgba(233, 231,251), rgba(252, 235, 253))",
        "linear(to-r, gray.700, gray.900)"
      )}
      display={{ lg: "none" }}
    >
      <HStack justifyContent="space-between" width="100%">
        <StackItem>
          <ColorModeSwitch />
        </StackItem>
        <StackItem>
          <LightMode>
            {/* <NextLink href="/swap"> */}
            <Button
              variant={"gradient"}
              colorScheme="brand"
              size={{ base: "md", md: "lg" }}
              color={"white"}
              onClick={enableComingSoon}
            >
              {i18n._(
                isComingSoon
                  ? t({ message: "Coming Soon" })
                  : t({ message: "Enter App" })
              )}
            </Button>
            {/* </NextLink> */}
          </LightMode>
        </StackItem>
      </HStack>
    </Box>
  );
};

export default Bar;
