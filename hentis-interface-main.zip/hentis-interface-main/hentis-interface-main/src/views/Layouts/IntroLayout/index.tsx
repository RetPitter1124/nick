import { Box } from "@chakra-ui/react";
import { ReactNode } from "react";
import Footer from "../MainLayout/Footer";
import Bar from "./Bar";
import Header from "./Header";

const IntroLayout = ({ children }: { children?: ReactNode }) => {
  return (
    <>
      <Header />
      <Box pt={{ base: "63px", md: "82px" }} minH="calc(100vh - 430px)">
        {children}
      </Box>
      <Footer />
      <Bar />
    </>
  );
};

export default IntroLayout;
