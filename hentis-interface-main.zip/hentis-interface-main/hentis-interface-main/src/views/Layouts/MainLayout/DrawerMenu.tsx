import { Link, List, ListItem, Text } from "@chakra-ui/react";
import NextLink from "next/link";
import { useRouter } from "next/router";
import { IMenuData } from "./menuData";

const DrawerMenu = ({ data }: { data: IMenuData[] }) => {
  const router = useRouter();
  return (
    <List pl="3">
      {data.map((item, index) => {
        const isActive = item.activeRoutes.exec(router.pathname)?.index === 0;
        if (item.children) {
          return (
            <ListItem key={index}>
              <Text
                fontWeight={isActive ? "bold" : "medium"}
                display="block"
                py="2"
              >
                {item.content}
              </Text>
              <DrawerMenu data={item.children} />
            </ListItem>
          );
        }
        return (
          <ListItem key={index}>
            <NextLink href={item.href || ""} passHref>
              <Link
                fontWeight={isActive ? "bold" : "medium"}
                display="block"
                py="2"
              >
                {item.content}
              </Link>
            </NextLink>
          </ListItem>
        );
      })}
    </List>
  );
};

export default DrawerMenu;
