import {
  HStack,
  Icon,
  Link,
  LinkBox,
  List,
  ListItem,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  chakra,
} from "@chakra-ui/react";
import NextLink from "next/link";
import { useRouter } from "next/router";
import { ReactNode } from "react";
import { HenRefresh } from "../../../components/Icons";
import { IMenuData } from "./menuData";
import { HiChevronDown } from "react-icons/hi";

const NavList = ({ children }: { children: ReactNode }) => (
  <HStack
    as={List}
    spacing={{ base: "10px", lg: "20px", xl: "40px" }}
    align={{
      lg: "center",
    }}
  >
    {children}
  </HStack>
);

const NavListItem = ({
  href,
  children,
  isExternal = false,
  isActive = false,
}: {
  href: string;
  children: ReactNode;
  isExternal?: boolean;
  isActive?: boolean;
}) => (
  <ListItem>
    <NextLink href={href} passHref>
      <Link
        href={href}
        isExternal={isExternal}
        fontSize={{ base: "19px" }}
        fontWeight={isActive ? "bold" : "medium"}
      >
        {children}
      </Link>
    </NextLink>
  </ListItem>
);

const SubNavMenu = ({ data }: { data: IMenuData }) => {
  const router = useRouter();
  const isActive = data.activeRoutes.exec(router.pathname)?.index === 0;
  return (
    <Menu>
      <MenuButton
        bgColor={"transparent"}
        fontSize={{ base: "19px" }}
        fontWeight={isActive ? "bold" : "medium"}
      >
        <chakra.span display="flex" alignItems={"center"}>
          {data.content}
          <Icon as={HiChevronDown} />
        </chakra.span>
      </MenuButton>
      <MenuList>
        {data.children?.map((item, index) => {
          const isActive = item.activeRoutes.exec(router.pathname)?.index === 0;
          return (
            <MenuItem
              key={index}
              fontWeight={isActive ? "bold" : "medium"}
              display={"block"}
            >
              <NextLink href={item.href || ""}>
                <Link display={"block"}>{item.content}</Link>
              </NextLink>
            </MenuItem>
          );
        })}
      </MenuList>
    </Menu>
  );
};

const NavMenu = ({ data }: { data: IMenuData[] }) => {
  const router = useRouter();
  return (
    <NavList>
      {data.map((item, index) => {
        if (item.children) {
          return (
            <ListItem key={index}>
              <SubNavMenu data={item} />
            </ListItem>
          );
        }

        const isActive = item.activeRoutes.exec(router.pathname)?.index === 0;
        return (
          <NavListItem
            key={index}
            href={item.href || ""}
            isExternal={item.isExternal}
            isActive={isActive}
          >
            {item.content}
          </NavListItem>
        );
      })}
    </NavList>
  );
};

export default NavMenu;
