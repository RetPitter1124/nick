import {
  Box,
  Container,
  Heading,
  HStack,
  Icon,
  Image,
  Link,
  List,
  ListItem,
  Stack,
  useColorModeValue,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { ReactNode } from "react";
import {
  FaDiscord,
  FaGithub,
  FaLinkedin,
  FaMedium,
  FaTelegramPlane,
  FaTwitter,
} from "react-icons/fa";
import logoSplendid from "../../../assets/logo-splendid.png";

const NavList = ({ children }: { children: ReactNode }) => (
  <Stack
    as={List}
    spacing={{ base: "5", lg: "10" }}
    direction={{
      base: "column",
      lg: "row",
    }}
    align={{
      lg: "center",
    }}
  >
    {children}
  </Stack>
);

const NavListItem = ({
  href,
  children,
  isExternal = false,
}: {
  href?: string;
  children: ReactNode;
  isExternal?: boolean;
}) => (
  <ListItem>
    <Link
      color="white"
      _hover={{
        color: "whiteAlpha.800",
      }}
      href={href}
      target={isExternal ? "_blank" : "_self"}
    >
      {children}
    </Link>
  </ListItem>
);

const SocialList = ({ children }: { children: ReactNode }) => (
  <HStack as={List} spacing={"10"}>
    {children}
  </HStack>
);

const SocialListItem = ({ href, icon }: { href?: string; icon: any }) => (
  <ListItem>
    <Link
      color="white"
      _hover={{
        color: "whiteAlpha.800",
      }}
      target={"_blank"}
      href={href}
      display={"block"}
      height={{ base: "6", sm: "7.5" }}
      fontSize={{ base: "2xl", sm: "3xl" }}
      lineHeight={1}
    >
      <Icon as={icon} />
    </Link>
  </ListItem>
);

const Footer = () => {
  const { i18n } = useLingui();
  return (
    <>
      <Box pt={{ base: 12, md: 24, lg: 28 }}>
        <Box
          bg="radial-gradient(104.02% 1653.9% at 0% 36.79%, #2314D4 0%, #E135F0 100%)"
          color="white"
          pt={{
            base: "24",
            lg: "36",
          }}
          pb={{
            base: "20",
            lg: "24",
          }}
          pos={"relative"}
        >
          <Box
            pos="absolute"
            p={{ base: "18.75px", lg: "25px" }}
            left="50%"
            top="0"
            marginLeft={{ base: "-75px", lg: "-100px" }}
            marginTop={{ base: "-75px", lg: "-100px" }}
            bgColor={useColorModeValue("gray.50", "gray.800")}
            borderRadius={"full"}
          >
            <Box
              p={{ base: "7.5px", lg: "10px" }}
              borderRadius={"full"}
              bgColor={"white"}
              boxShadow={{
                base: "0px -1.5px 15px rgba(225, 53, 240, 0.75)",
                lg: "0px -2px 20px rgba(225, 53, 240, 0.75)",
              }}
            >
              <Box
                bg={"linear-gradient(150deg, #2314D4,#23CAE1, #E135F0)"}
                p={{ base: "7.5px", lg: "10px" }}
                borderRadius={"full"}
              >
                <Box
                  p={{ base: "7.5px", lg: "10px" }}
                  bgColor={"white"}
                  borderRadius="full"
                >
                  <Image
                    src={"/apple-touch-icon.png"}
                    width={{ base: "67.5px", lg: "90px" }}
                    height={{ base: "67.5px", lg: "90px" }}
                    alt={i18n._(t({ message: "Hentis.One" }))}
                  />
                </Box>
              </Box>
            </Box>
          </Box>
          <Container
            maxW={{
              base: "container.sm",
              md: "container.md",
              lg: "container.lg",
              xl: "container.xl",
              "2xl": "container.2xl",
            }}
          >
            <Stack
              direction={{
                base: "column",
                lg: "row",
              }}
              spacing={{ base: "30px", lg: "40px" }}
            >
              <HStack>
                <Image
                  src={"/apple-touch-icon.png"}
                  alt="Hentis"
                  width={{
                    base: "35px",
                    md: "55px",
                    lg: "70px",
                  }}
                />
                <Heading
                  color="white"
                  fontSize={{
                    base: "20px",
                    md: "30px",
                    lg: "40px",
                  }}
                >
                  {i18n._(t({ message: "Hentis.one" }))}
                </Heading>
              </HStack>
              <NavList>
                <NavListItem href="mailto:contact@hentis.one">
                  {i18n._(t({ message: "Contact Us" }))}
                </NavListItem>
                <NavListItem href="https://docs.hentis.one" isExternal>
                  {i18n._(t({ message: "Document" }))}
                </NavListItem>
                <NavListItem href="http://hentis.medium.com" isExternal>
                  {i18n._(t({ message: "Blog" }))}
                </NavListItem>
              </NavList>
              <SocialList>
                <SocialListItem
                  icon={FaDiscord}
                  href="https://discord.gg/NBnhV8tsjj"
                />
                <SocialListItem
                  icon={FaTwitter}
                  href="https://twitter.com/Hentis_one"
                />
                <SocialListItem
                  icon={FaTelegramPlane}
                  href="https://t.me/Hentis_one"
                />
                <SocialListItem
                  icon={FaLinkedin}
                  href="https://www.linkedin.com/company/hentis-one/"
                />
                <SocialListItem
                  icon={FaGithub}
                  href="https://github.com/hentis-one"
                />
                <SocialListItem
                  icon={FaMedium}
                  href="http://hentis.medium.com"
                />
              </SocialList>
            </Stack>
            <Box paddingTop="6">
              {i18n._(
                t({ message: "© 2022 Hentis.one. All rights reserved." })
              )}
            </Box>
          </Container>
        </Box>
      </Box>
    </>
  );
};

export default Footer;
