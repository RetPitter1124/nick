import {
  Box,
  Button,
  Container,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  HStack,
  Icon,
  IconButton,
  Image,
  LightMode,
  Link,
  StackItem,
  useColorModeValue,
  useDisclosure,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import NextLink from "next/link";

import { FiMenu } from "react-icons/fi";
import { HiLockClosed, HiOutlineArrowRight } from "react-icons/hi";
import { RiWallet3Line } from "react-icons/ri";
import CurrencyBadge from "../../../components/Currency/CurrencyBadge";
import ColorModeSwitch from "../../../components/Switch/ColorModeSwitch";
import { useCounter } from "../../../state/counter/hooks";
import DrawerMenu from "./DrawerMenu";
import menuData from "./menuData";
import NavMenu from "./NavMenu";

const Header = () => {
  const { i18n } = useLingui();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [count, increment, decrement] = useCounter();
  return (
    <Box
      py="14px"
      pos={"fixed"}
      left="0"
      top="0"
      w="100%"
      zIndex={"999"}
      bgGradient={useColorModeValue(
        "linear(to-r, rgba(233, 231,251), rgba(252, 235, 253))",
        "linear(to-r, gray.700, gray.900)"
      )}
    >
      <Container
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
          "2xl": "container.2xl",
        }}
      >
        <HStack
          justifyContent={"space-between"}
          spacing={{ base: "3", lg: "8" }}
        >
          <StackItem>
            <HStack spacing={{ base: "3", lg: "8" }}>
              <StackItem>
                <NextLink href={"/"} passHref>
                  <Link>
                    <Image
                      src={"/apple-touch-icon.png"}
                      w={{ base: "35px", md: "54px" }}
                      alt={i18n._(t({ message: "Hentis.One" }))}
                    />
                  </Link>
                </NextLink>
              </StackItem>
              <StackItem>
                <CurrencyBadge />
              </StackItem>
            </HStack>
          </StackItem>
          <StackItem display={{ base: "none", lg: "block" }}>
            <NavMenu data={menuData} />
          </StackItem>
          <StackItem>
            <HStack spacing={{ base: "3", lg: "8" }}>
              <StackItem display={{ base: "none", lg: "block" }}>
                <ColorModeSwitch />
              </StackItem>
              <StackItem display={{ base: "none", lg: "block" }}>
                <LightMode>
                  <Button
                    variant={"gradient"}
                    colorScheme="brand"
                    size={{ base: "md", md: "lg" }}
                    leftIcon={<RiWallet3Line fontSize={"1.5em"} />}
                    color={"white"}
                    onClick={increment}
                  >
                    {i18n._(t({ message: "Connect Wallet" }))}
                  </Button>
                </LightMode>
              </StackItem>
              <StackItem>
                <IconButton
                  padding="0"
                  aria-label=""
                  display={{ base: "block", lg: "none" }}
                  onClick={onOpen}
                  bgColor={useColorModeValue("white", "black")}
                  color={useColorModeValue("black", "white")}
                  icon={<Icon as={FiMenu} pt="1" fontSize={"3xl"} />}
                />
              </StackItem>
            </HStack>
          </StackItem>
        </HStack>
      </Container>
      <Drawer isOpen={isOpen} placement="right" onClose={onClose} size="full">
        <DrawerOverlay />
        <DrawerContent>
          <DrawerHeader
            py="14px"
            px="4"
            bgGradient={useColorModeValue(
              "linear(to-r, rgba(233, 231,251), rgba(252, 235, 253))",
              "linear(to-r, gray.700, gray.900)"
            )}
          >
            <HStack justifyContent={"space-between"}>
              <StackItem>
                <NextLink href={"/"} passHref>
                  <Link>
                    <Image
                      src={"/apple-touch-icon.png"}
                      w={{ base: "35px", md: "54px" }}
                      alt={i18n._(t({ message: "Hentis.One" }))}
                    />
                  </Link>
                </NextLink>
              </StackItem>
              <StackItem>
                <IconButton
                  padding="0"
                  aria-label=""
                  display={{ base: "block", lg: "none" }}
                  onClick={onClose}
                  bgColor={useColorModeValue("white", "black")}
                  color={useColorModeValue("black", "white")}
                  icon={
                    <Icon as={HiOutlineArrowRight} pt="1" fontSize={"3xl"} />
                  }
                />
              </StackItem>
            </HStack>
          </DrawerHeader>
          <DrawerBody>
            <Box ml="-3">
              <DrawerMenu data={menuData} />
            </Box>
          </DrawerBody>
          <DrawerFooter></DrawerFooter>
        </DrawerContent>
      </Drawer>
    </Box>
  );
};

export default Header;
