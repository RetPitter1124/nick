import { Box } from "@chakra-ui/react";
import { ReactNode } from "react";
import Bar from "./Bar";
import Footer from "./Footer";
import Header from "./Header";

const MainLayout = ({ children }: { children?: ReactNode }) => {
  return (
    <>
      <Header />
      <Box pt={{ base: "68px", md: "82px" }} minH="calc(100vh - 430px)">
        {children}
      </Box>
      <Footer />
      <Bar />
    </>
  );
};

export default MainLayout;
