import { i18n } from "@lingui/core";
import { t } from "@lingui/macro";
import { ReactNode } from "react";

export interface IMenuData {
  href?: string;
  isExternal?: boolean;
  content?: ReactNode;
  children?: IMenuData[];
  activeRoutes: RegExp;
}

const menuData = [
  {
    content: i18n._(t({ message: "Swap" })),
    activeRoutes: /\/swap|\/liquidity/,
    children: [
      {
        href: "/swap",
        content: i18n._(t({ message: "Swap" })),
        activeRoutes: /\/swap/,
      },
      {
        href: "/liquidity",
        content: i18n._(t({ message: "Liquidity" })),
        activeRoutes: /\/liquidity/,
      },
    ],
  },
  {
    content: i18n._(t({ message: "Earn" })),
    activeRoutes: /\/pools|\/farms/,
    children: [
      {
        href: "/pools",
        content: i18n._(t({ message: "Pools" })),
        activeRoutes: /\/pools/,
      },
      {
        href: "/farms",
        content: i18n._(t({ message: "Farms" })),
        activeRoutes: /\/farms/,
      },
    ],
  },
  {
    href: "/launchpad",
    content: i18n._(t({ message: "Launchpad" })),
    activeRoutes: /\/launchpad/,
  },
  {
    href: "/lending",
    content: i18n._(t({ message: "Lending" })),
    activeRoutes: /\/lending/,
  },
  {
    content: i18n._(t({ message: "More" })),
    activeRoutes: /\/analytics/,
    children: [
      {
        href: "analytics",
        content: i18n._(t({ message: "Analytics" })),
        activeRoutes: /\/analytics/,
      },
    ],
  },
] as IMenuData[];

export default menuData;
