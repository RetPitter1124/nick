import { Container } from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import type { NextPage } from "next";
import Head from "next/head";
import MainLayout from "../Layouts/MainLayout";
import LiquidityPanel from "./LiquidityPanel";

const Liquidity: NextPage = () => {
  const { i18n } = useLingui();
  return (
    <>
      <Head>
        <title>
          {`${i18n._(t({ message: "Liquidity" }))} | 
            ${i18n._(t({ message: "Hentis.One" }))}`}
        </title>
      </Head>
      <MainLayout>
        <Container py="8" maxW="lg">
          <LiquidityPanel />
        </Container>
      </MainLayout>
    </>
  );
};

export default Liquidity;
