import {
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  Text,
  HStack,
  StackItem,
  Image,
  useColorModeValue,
  VStack,
  Link,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { ReactNode } from "react";
import imgJohn from "../../assets/team/john.png";
import imgNick from "../../assets/team/nick.png";
import imgJoshua from "../../assets/team/joshua.png";
import imgTiago from "../../assets/team/tiago.png";
import imgZhjing from "../../assets/team/zh.png";
import imgMicky from "../../assets/team/micky.png";
import { HenLinkedin } from "../../components/Icons/HenLinkedin";
import { HenTwitter } from "../../components/Icons/HenTwitter";

interface PeopleCardProps {
  label: ReactNode;
  image: ReactNode;
  role: string;
  text: ReactNode;
  social: any | null;
}

const PeopleCard = ({ label, image, role, text, social }: PeopleCardProps) => {
  return (
    <Grid
      maxW={"488px"}
      mx="auto"
      py={"12"}
      background={useColorModeValue("black", "white")}
      borderRadius={"4"}
      height="100%"
      templateColumns={"repeat(2, 1fr)"}
      gap={{ base: 0, md: 4 }}
      alignItems="stretch"
    >
      <GridItem colSpan={{ base: 1, md: 1 }}>
        <StackItem width={"100%"}>{image}</StackItem>
      </GridItem>
      <GridItem colSpan={{ base: 1, md: 1 }}>
        <VStack alignItems={"center"} height="100%" textAlign={"left"}>
          <StackItem
            width={"100%"}
            mt={6}
            color={useColorModeValue("white", "black")}
          >
            <Heading size="md" fontWeight={"light"}>
              {label}
            </Heading>
            <HStack alignItems={"center"} justifyContent={"space-between"}>
              <Heading
                size="md"
                fontWeight={"medium"}
                color={useColorModeValue("white", "black")}
              >
                {role}
              </Heading>
              <Link href={social?.linkedin} isExternal>
                <HenLinkedin
                  fontSize={"2xl"}
                  mr={12}
                  mt={0}
                  color={useColorModeValue("white", "black")}
                />
              </Link>
              {/* <Link href={social?.twitter} isExternal>
                <HenTwitter />
              </Link> */}
            </HStack>
          </StackItem>
          {/* <StackItem
            width="100%"
            color={useColorModeValue(
              "black",
              role === "Advisor" ? "black" : "white"
            )}
          >
            <Text
              as={"div"}
              fontWeight={"medium"}
              fontSize={{ base: "md", md: "md", lg: "lg" }}
            >
              {text}
            </Text>
          </StackItem> */}
        </VStack>
      </GridItem>
    </Grid>
  );
};

const Teams = () => {
  const { i18n } = useLingui();
  const teams = [
    {
      label: i18n._(t({ message: "John Olumide" })),
      image: (
        <Image src={imgJohn.src} alt="" mx={"auto"} width={{ base: "100px" }} />
      ),
      role: "CEO",
      text: i18n._(
        t({
          message: `He is responsible for the UI/UX design at Hentis.`,
        })
      ),
      social: {
        linkedin: "https://www.linkedin.com/in/john-olumide-4377031b6",
        twitter: "https://twitter.com/John_Olumi",
      },
    },
    {
      label: i18n._(t({ message: "Nick Jackson" })),
      image: (
        <Image src={imgNick.src} alt="" mx={"auto"} width={{ base: "100px" }} />
      ),
      role: "CTO",
      text: i18n._(
        t({
          message: `He is responsible for the technical development at Hentis.`,
        })
      ),
      social: {
        linkedin: "https://www.linkedin.com/in/nick-j-jackson",
        twitter: "https://twitter.com/nick-j-jackson",
      },
    },
    {
      label: i18n._(t({ message: "Joshua Adeolu" })),
      image: (
        <Image
          src={imgJoshua.src}
          alt=""
          mx={"auto"}
          width={{ base: "100px" }}
        />
      ),
      role: "CFO",
      text: i18n._(
        t({
          message: `He is responsible for the products management at Hentis.`,
        })
      ),
      social: {
        linkedin: "https://www.linkedin.com/in/joshua-adeolu-023695186",
        twitter: "https://twitter.com/JoshEclipse19",
      },
    },
    {
      label: i18n._(t({ message: "Tiago Pratas" })),
      image: (
        <Image
          src={imgTiago.src}
          alt=""
          mx={"auto"}
          width={{ base: "100px" }}
        />
      ),
      role: "Advisor",
      text: i18n._(
        t({
          message: `He is responsible for business advisory at Hentis.`,
        })
      ),
      social: {
        linkedin: "https://www.linkedin.com/in/tiagotpratas",
        twitter: "https://twitter.com/longpratas",
      },
    },
  ];

  return (
    <Box background="linear-gradient(90deg, rgba(35, 20, 212, 0.1) 0%, rgba(255, 255, 255, 0.1) 33.71%, rgba(255, 255, 255, 0.1) 49.86%, rgba(255, 255, 255, 0.1) 58.71%, rgba(225, 53, 240, 0.1) 100%)">
      <Container
        py={{
          base: "2",
          md: "4",
          lg: "8",
        }}
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
        }}
        pos="relative"
      >
        <Heading
          as={"h2"}
          textAlign="center"
          fontWeight="bold"
          mb={{ base: 4 }}
          fontSize={{ base: "3xl", md: "4xl", lg: "5xl" }}
        >
          {i18n._(t({ message: "Team" }))}
        </Heading>
        <Grid
          templateColumns={"repeat(3, 1fr)"}
          gap={{ base: 16 }}
          alignItems="stretch"
        >
          {teams.map((item, index) => (
            <GridItem key={index} colSpan={{ base: 3, md: 1 }}>
              <PeopleCard {...item} />
            </GridItem>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Teams;
