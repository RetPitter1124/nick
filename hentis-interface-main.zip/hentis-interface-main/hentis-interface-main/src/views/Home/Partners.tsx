import {
  AspectRatio,
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  Image,
  useColorModeValue,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { ReactNode } from "react";
import imgIronsFoundation from "../../assets/partners/irons_foundation.png";

interface StartCardProps {
  label: ReactNode;
  image?: ReactNode;
  href?: string;
}

const PartnerCard = ({ image }: StartCardProps) => {
  return (
    <AspectRatio ratio={{ base: 3, lg: 3.5 }}>
      <Box
        borderRadius={"10px"}
        bgGradient={"linear(to-r, #2314D4, #E135F0)"}
        pos={"relative"}
      >
        <Box
          borderRadius={"9px"}
          pos={"absolute"}
          left="1px"
          top="1px"
          right="1px"
          bottom="1px"
          display="flex"
          justifyContent="center"
          bgColor={useColorModeValue("white", "white")}
        >
          {image}
        </Box>
      </Box>
    </AspectRatio>
  );
};

const Partners = () => {
  const { i18n } = useLingui();
  const items = [
    {
      label: "Irons foundation",
      image: <Image src={imgIronsFoundation.src} alt="Irons foundation" />,
    },
    {
      label: "",
    },
    {
      label: "",
    },
    {
      label: "",
    },
    {
      label: "",
    },
    {
      label: "",
    },
  ];

  return (
    <Box>
      <Container
        pt={{
          base: 6,
          md: 8,
          lg: 10,
        }}
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
        }}
      >
        <Heading
          textAlign={"center"}
          as={"h2"}
          fontWeight="bold"
          mb={{ base: 6, sm: 6, md: 8, lg: 14 }}
          fontSize={{ base: "3xl", md: "4xl", lg: "5xl" }}
        >
          {i18n._(t({ message: "Investors & Partners" }))}
        </Heading>
        <Grid
          templateColumns={"repeat(6, 1fr)"}
          gap={{ base: 4, sm: 8, md: 16, lg: 24 }}
          mb={{ base: 10 }}
        >
          {items.map((item, index) => (
            <GridItem
              key={index}
              colSpan={{ base: 3, md: 2 }}
              my={{ base: 0, sm: 0, md: -4, lg: -8 }}
            >
              <PartnerCard {...item} />
            </GridItem>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Partners;
