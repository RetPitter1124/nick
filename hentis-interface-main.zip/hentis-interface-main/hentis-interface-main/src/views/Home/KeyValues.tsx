import {
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  VStack,
  StackItem,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { ReactNode } from "react";
import { HenCode } from "../../components/Icons/HenCode";
import { HenCustomerSupport } from "../../components/Icons/HenCustomerSupport";
import { HenUX } from "../../components/Icons/HenUX";

interface CardProps {
  label: ReactNode;
  image: ReactNode;
}

const Card = ({ label, image }: CardProps) => {
  return (
    <VStack
      maxW={"488px"}
      mx="auto"
      height="100%"
      borderRadius={16}
      bgGradient="linear-gradient(26deg, #2314D4 38.81%, #E135F0 100.74%);"
      color={"white"}
      padding={{ base: 4, md: 6, lg: 8 }}
    >
      <StackItem width="100%" textAlign={"center"} fontSize={"5xl"}>
        {image}
      </StackItem>
      <StackItem width="100%">
        <Heading as="h3" size="md" textAlign={"center"} fontWeight={"bold"}>
          {label}
        </Heading>
      </StackItem>
    </VStack>
  );
};

const KeyValues = () => {
  const { i18n } = useLingui();
  const items = [
    {
      label: i18n._(t({ message: "Improvement on User Experience" })),
      image: <HenUX />,
    },
    {
      label: i18n._(t({ message: "Advanced dApps Functionality" })),
      image: <HenCode />,
    },
    {
      label: i18n._(t({ message: "Customer Support System" })),
      image: <HenCustomerSupport />,
    },
  ];
  return (
    <Box bg="linear-gradient(90deg, rgba(35, 20, 212, 0.1) 0%, rgba(255, 255, 255, 0.1) 33.71%, rgba(255, 255, 255, 0.1) 49.86%, rgba(255, 255, 255, 0.1) 58.71%, rgba(225, 53, 240, 0.1) 100%)">
      <Container
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
        }}
        pos="relative"
      >
        <Heading
          as={"h2"}
          textAlign="center"
          fontWeight="bold"
          mb={8}
          fontSize={{ base: "3xl", md: "4xl", lg: "5xl" }}
        >
          {i18n._(t({ message: "Key Focus" }))}
        </Heading>
        <Grid
          templateColumns={"repeat(3, 1fr)"}
          gap={{ base: 4, md: 12, lg: 24 }}
          alignItems="stretch"
        >
          {items.map((item, index) => (
            <GridItem key={index} colSpan={{ base: 3, md: 1 }}>
              <Card {...item} />
            </GridItem>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default KeyValues;
