import {
  Box,
  Button,
  Container,
  Heading,
  HStack,
  Image,
  Stack,
  StackItem,
  Text,
  useColorModeValue,
  useDisclosure,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import NextLink from "next/link";
import { ReactNode } from "react";
import imgIconA from "../../assets/intro/icon-a.png";
import imgIconUpDown from "../../assets/intro/icon-updown.png";
import imgIconUsers from "../../assets/intro/icon-users.png";
import { useComingSoon } from "../../state/global/hooks";

interface FeatureItemProps {
  title: ReactNode;
  content: ReactNode;
  icon?: string;
  slogan: string;
  index: number;
}

const FeatureCard = ({
  title = "",
  content = "",
  icon,
  slogan = "",
  index,
}: FeatureItemProps) => {
  const [isComingSoon, enableComingSoon] = useComingSoon();
  const { i18n } = useLingui();
  return (
    <Box
      bg={
        index % 2 === 1
          ? "linear-gradient(90deg, rgba(35, 20, 212, 0.1) 0%, rgba(255, 255, 255, 0.1) 33.71%, rgba(255, 255, 255, 0.1) 49.86%, rgba(255, 255, 255, 0.1) 58.71%, rgba(225, 53, 240, 0.1) 100%)"
          : "transparent"
      }
      // overflow="hidden"
    >
      <Container
        py={{ base: 6, md: 16, lg: 24 }}
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
        }}
        pos={"relative"}
      >
        {index <= 1 && (
          <Image
            pos={"absolute"}
            src={icon}
            transform={"rotate(45deg)"}
            alt=""
            left={index == 0 ? { base: "8px", md: "initial" } : { md: "-64px" }}
            right={
              index == 0 ? { md: "-64px" } : { base: "8px", md: "initial" }
            }
            top={index === 0 ? { base: "-15px", md: "-64px" } : {}}
            bottom={index === 0 ? {} : { base: "-15px", md: "-64px" }}
            width={{ base: "30px", md: "129px" }}
          />
        )}
        <Stack
          justifyContent={"space-between"}
          alignItems="center"
          direction={{
            base: "column-reverse",
            md: index % 2 === 1 ? "row-reverse" : "row",
          }}
        >
          <StackItem width={{ base: "100%", md: "60%" }}>
            <Heading
              as={"h2"}
              fontWeight="medium"
              fontSize={{ base: "2xl", md: "3xl", lg: "4xl" }}
              mb={{ base: 2 }}
            >
              {title}
            </Heading>
            <Text
              as="div"
              fontSize={{ base: "sm", md: "md", lg: "lg" }}
              mb={{ base: 4, md: 6 }}
            >
              {content}
            </Text>
            <Box textAlign={{ md: index % 2 === 1 ? "right" : "left" }}>
              {/* <NextLink href="/swap"> */}
              <Button
                colorScheme={"brand"}
                variant="gradient"
                px={{ base: "8", md: "12" }}
                py={{ base: "4", md: "6" }}
                onClick={enableComingSoon}
              >
                {i18n._(
                  isComingSoon
                    ? t({ message: "Coming Soon" })
                    : t({ message: "Enter App" })
                )}
              </Button>
              {/* </NextLink> */}
            </Box>
          </StackItem>
          <StackItem>
            <Box
              bg="radial-gradient(119.63% 1901.26% at -5.56% 40.7%, rgba(225, 53, 240, 0.17) 0%, rgba(35, 20, 212, 0.17) 100%)"
              boxShadow="0px -25px 100px rgba(35, 20, 212, 0.75), 0px 35px 150px rgba(225, 53, 240, 0.75)"
              borderRadius={10}
              maxW="100%"
              w={{ base: "149px", md: "270px" }}
              h={{ base: "109px", md: "199px" }}
              pos="relative"
              mb={{ base: 6 }}
              mr={{ base: 6, md: 10 }}
            >
              <Image src={icon} alt="" width={{ base: "79px", md: "146px" }} />
              <HStack
                pos="absolute"
                bgColor={useColorModeValue("white", "gray.900")}
                left={{ base: 6, md: 10 }}
                width={{ base: "180px", md: "295px" }}
                bottom={{ md: "-40px" }}
                borderRadius={6}
                p={{ md: 2 }}
              >
                <Image
                  src={icon}
                  alt=""
                  w={{ base: "40px", md: "73px" }}
                  transform={
                    index === 0
                      ? "rotate(90deg)"
                      : index === 1
                      ? "rotate(45deg)"
                      : "rotate(0deg)"
                  }
                />
                <Text
                  as="div"
                  fontSize={{ base: "9px", md: "sm" }}
                  fontWeight={{ base: "semibold", md: "medium" }}
                >
                  {slogan}
                </Text>
              </HStack>
            </Box>
          </StackItem>
        </Stack>
      </Container>
    </Box>
  );
};
const Features = () => {
  const { i18n } = useLingui();
  const features = [
    {
      title: i18n._(t({ message: "Meta DEX" })),
      content: i18n._(
        t({
          message:
            "Advanced DEX with fee discounts, Light-speed swap, friction-less yields and low gas fee on Sui. Trade just any fungible token on Sui within seconds.",
        })
      ),
      slogan: i18n._(
        t({ message: "TRADE JUST ANY FUNGLE TOKEN ON SUI IN SECONDS." })
      ),
      icon: imgIconUpDown.src,
    },
    {
      title: i18n._(t({ message: "Launchpad" })),
      content: i18n._(
        t({
          message:
            "An Innovative launchpad that helps facilitate projects within the Sui ecosystem with fundraising, engagement, growth, advisory, liquidity and trading solutions.",
        })
      ),
      slogan: i18n._(
        t({ message: "INVEST IN HIGH QUALITY SUI ECOSYSTEM PROJECTS." })
      ),
      icon: imgIconA.src,
    },
    {
      title: i18n._(t({ message: "Lending Protocol" })),
      content: i18n._(
        t({
          message:
            "Instant and permisionless peer-peer Defi lending protocol that allow users to invest in digital assets through multi pool borrowing. Lend supported assets on Hentis Vault and earn incredible organic yields.",
        })
      ),
      slogan: i18n._(
        t({ message: "LEND AND BORROW DIGITAL ASSETS WITHIN SECONDS." })
      ),
      icon: imgIconUsers.src,
    },
  ];
  return (
    <>
      {features.map((item, index) => (
        <FeatureCard key={index} {...item} index={index} />
      ))}
    </>
  );
};

export default Features;
