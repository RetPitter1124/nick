import {
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  HStack,
  Image,
  Link,
  StackItem,
  Text,
  useColorModeValue,
  VStack,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import NextLink from "next/link";
import { ReactNode } from "react";
import { HenArrowRightGB } from "../../components/Icons";

interface StartCardProps {
  label: ReactNode;
  text: ReactNode;
  href?: string;
}

const StartCard = ({ label, text, href = "" }: StartCardProps) => {
  return (
    <VStack
      maxW={"488px"}
      mx="auto"
      height="100%"
      borderTopRadius={16}
      bgGradient="linear(to-r, #2314D4, #E135F0)"
      color={"white"}
      padding={{ base: 4, md: 6, lg: 8 }}
    >
      <StackItem width="100%">
        <HStack justifyContent={"space-between"}>
          <Heading as="h3" size="md" fontWeight={"medium"}>
            {label}
          </Heading>
          <NextLink href={href}>
            <Link>
              <HenArrowRightGB fontSize={"3xl"} />
            </Link>
          </NextLink>
        </HStack>
      </StackItem>
      <StackItem width="100%">
        <Text
          as={"div"}
          color={"white"}
          fontSize={{ base: "sm", md: "md", lg: "lg" }}
        >
          {text}
        </Text>
      </StackItem>
    </VStack>
  );
};

const GetStarted = () => {
  const { i18n } = useLingui();
  const items = [
    {
      label: i18n._(t({ message: "PRODUCT GUIDES" })),
      text: i18n._(
        t({
          message:
            "Get a deeper understanding about Hentis dApps & learn about all passive the income opportunities available.",
        })
      ),
    },
    {
      label: i18n._(t({ message: "BUILD" })),
      text: i18n._(
        t({
          message:
            "Integrate Hentis SDK and Smart contract to build your own dApps and interact with the protocol.",
        })
      ),
    },
  ];

  return (
    <Box bg="linear-gradient(90deg, rgba(35, 20, 212, 0.1) 0%, rgba(255, 255, 255, 0.1) 33.71%, rgba(255, 255, 255, 0.1) 49.86%, rgba(255, 255, 255, 0.1) 58.71%, rgba(225, 53, 240, 0.1) 100%)">
      <Container
        pt={{
          base: "16",
          md: "24",
          lg: "36",
        }}
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
        }}
      >
        <Heading
          as={"h2"}
          textAlign="center"
          fontWeight="bold"
          mb={{ base: 4 }}
          fontSize={{ base: "3xl", md: "4xl", lg: "5xl" }}
        >
          {i18n._(t({ message: "Get Started With Hentis" }))}
        </Heading>
        <Text
          fontSize={{ base: "lg", md: "md", lg: "lg" }}
          fontWeight="medium"
          textAlign="center"
          mb={20}
          color={useColorModeValue("gray.700", "gray.100")}
        >
          {i18n._(
            t({
              message: `Get to know the power of Defi products and passive earnings features in the Hentis ecosystem.`,
            })
          )}
        </Text>
        <Grid
          templateColumns={"repeat(2, 1fr)"}
          gap={{ base: 4, md: 12, lg: 24 }}
          alignItems="stretch"
        >
          {items.map((item, index) => (
            <GridItem key={index} colSpan={{ base: 2, md: 1 }}>
              <StartCard {...item} />
            </GridItem>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default GetStarted;
