import {
  Box,
  Container,
  Grid,
  GridItem,
  Text,
  useColorModeValue,
  useInterval,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { useState } from "react";
import numeral from "numeral";

interface ValueProps {
  label: string;
  value: number;
}

const Value = ({ label, value }: ValueProps) => {
  const [count, setCount] = useState<number>(value);

  useInterval(() => {
    let temp = count - Math.floor(Math.random() * 100);
    if (temp <= 0) {
      temp = value;
    }
    setCount(temp);
  }, 1000);

  return (
    <Box
      borderTopRadius={"10"}
      bgColor={useColorModeValue("white", "gray.900")}
      p="6"
      maxW={{ base: "270px", lg: "initial" }}
      margin="auto"
      textAlign={"center"}
    >
      <Text fontSize={"xs"} fontWeight="medium" mb="1">
        {label}
      </Text>
      <Text
        fontSize={"lg"}
        fontWeight="semibold"
        color={useColorModeValue("blue", "blue.200")}
      >
        {numeral(count).format("$0,0")}
      </Text>
    </Box>
  );
};

const Values = () => {
  const { i18n } = useLingui();
  const values = [
    {
      label: i18n._(t({ message: "TOTAL VALUE LOCKED" })),
      value: 1205443771,
    },
    {
      label: i18n._(t({ message: "TOTAL TRADING VOLUME" })),
      value: 1205443771,
    },
    {
      label: i18n._(t({ message: "TOTAL FUND RAISED" })),
      value: 1000000,
    },
  ];
  return (
    <Box mt="-12">
      <Container
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
          "2xl": "container.2xl",
        }}
      >
        <Grid templateColumns="repeat(3, 1fr)" gap={{ base: 10, lg: 24 }}>
          {values.map((value, index) => (
            <GridItem colSpan={{ base: 3, md: 1 }} key={index}>
              <Value {...value} />
            </GridItem>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Values;
