import {
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  Image,
  Text,
  useColorMode,
  useColorModeValue,
} from "@chakra-ui/react";
import { i18n } from "@lingui/core";
import { t } from "@lingui/macro";
import imgEye from "../../assets/intro/eye.png";

const About = () => {
  return (
    <Container
      my={{ base: "12", lg: "24" }}
      maxW={{
        base: "container.sm",
        md: "container.md",
        lg: "container.lg",
        xl: "container.xl",
        "2xl": "container.2xl",
      }}
      pos="relative"
    >
      <Box
        background="radial-gradient(100% 1589.95% at 0% 36.79%, rgba(255, 255, 255, 0.85) 0%, rgba(255, 255, 255, 0) 100%), radial-gradient(104.02% 1653.9% at 0% 36.79%, rgba(35, 20, 212, 0.3) 0%, rgba(225, 53, 240, 0.29) 100%)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius={{ base: 0, md: 16 }}
        mx={{ base: -4, md: 0 }}
        px={{ base: 2, md: 4 }}
        pt={{ base: 3, md: 6 }}
        pb={{ base: 14, md: 6 }}
      >
        <Box
          background="radial-gradient(100% 1589.95% at 0% 36.79%, rgba(255, 255, 255, 0.85) 0%, rgba(255, 255, 255, 0) 100%), radial-gradient(104.02% 1653.9% at 0% 36.79%, rgba(35, 20, 212, 0.3) 0%, rgba(255, 255, 255, 0.5) 52.46%, rgba(225, 53, 240, 0.29) 100%)"
          borderRadius={16}
          border="2px solid white"
        >
          <Grid templateColumns={"repeat(18, 1fr)"} alignItems="center">
            <GridItem colSpan={{ base: 1, md: 6, lg: 5, xl: 4 }}>
              <Image
                my={{ base: 0, md: -5 }}
                src={imgEye.src}
                alt=""
                pos={{ base: "absolute", md: "initial" }}
                right={"-10px"}
                bottom={"-45px"}
                width={{ base: "180px", md: "auto" }}
              />
            </GridItem>
            <GridItem
              colSpan={{ base: 18, md: 12, lg: 13, xl: 14 }}
              px={{ base: 4 }}
              py={{ base: 10, md: 4 }}
              color={useColorModeValue("black", "black")}
            >
              <Heading
                as={"h2"}
                fontWeight="medium"
                mb={{ base: 4 }}
                fontSize={{ base: "2xl", md: "3xl", lg: "4xl" }}
              >
                {i18n._(t({ message: "About Hentis" }))}
              </Heading>
              <Text fontSize={{ base: "sm", md: "md", lg: "lg" }} mb={10}>
                {i18n._(
                  t({
                    message: `Hentis is a Defi ecosystem that combines a suite of features powering the evolution of decentralized finance on Sui. This enables users to trade any fungible token on Sui network, A single platform that incorporates Fundraising, lending and borrowing within the sui ecosystem`,
                  })
                )}
              </Text>
            </GridItem>
          </Grid>
        </Box>
      </Box>
    </Container>
  );
};

export default About;
