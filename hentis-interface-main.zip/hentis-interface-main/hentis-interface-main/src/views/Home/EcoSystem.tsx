import {
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  Text,
  VStack,
  StackItem,
  Image,
  UnorderedList,
  ListItem,
  useColorModeValue,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { ReactNode } from "react";
import imgMetaDex from "../../assets/intro/metadex.png";
import imgLaunchPad from "../../assets/intro/launchpad.png";
import imgMoneyMarket from "../../assets/intro/moneymarket.png";

interface CardProps {
  label: ReactNode;
  image: ReactNode;
  text: ReactNode;
  lists: Array<ReactNode>;
}

const Card = ({ label, image, text, lists }: CardProps) => {
  return (
    <VStack
      maxW={"488px"}
      mx="auto"
      height="100%"
      borderRadius={16}
      bgGradient="linear-gradient(26deg, #2314D4 38.81%, #E135F0 100.74%);"
      color={"white"}
      padding={{ base: 4, md: 6, lg: 8 }}
    >
      <StackItem width="100%" textAlign={"center"} fontSize={"5xl"}>
        {image}
      </StackItem>
      <StackItem width="100%">
        <Heading
          as="h3"
          my={4}
          size="lg"
          textAlign={"center"}
          fontWeight={"bold"}
        >
          {label}
        </Heading>
      </StackItem>
      <StackItem width="100%">
        <Text as={"div"} color={"white"} fontSize={{ base: "sm", md: "md" }}>
          {text}
        </Text>
        <UnorderedList my={4}>
          {lists.map((list, key) => (
            <ListItem key={key}>{list}</ListItem>
          ))}
        </UnorderedList>
      </StackItem>
    </VStack>
  );
};

const EcoSystem = () => {
  const { i18n } = useLingui();
  const items = [
    {
      label: i18n._(t({ message: "Meta DEX" })),
      image: (
        <Image
          src={imgMetaDex.src}
          alt=""
          mx={"auto"}
          width={{ base: "180px", md: "auto" }}
        />
      ),
      text: i18n._(t({ message: "Go-to trade platform on Sui network." })),
      lists: [
        i18n._(t({ message: "Swap tokens with low gas costs." })),
        i18n._(t({ message: "Provide liquidity and earn trading fees." })),
        i18n._(
          t({
            message: "Enjoy fee discounts for holding Hentis governance token.",
          })
        ),
      ],
    },
    {
      label: i18n._(t({ message: "Launchpad" })),
      image: (
        <Image
          src={imgLaunchPad.src}
          alt=""
          mx={"auto"}
          width={{ base: "180px", md: "auto" }}
        />
      ),
      text: i18n._(
        t({
          message: "Go-to launch platform for Sui network ecosystem projects.",
        })
      ),
      lists: [
        i18n._(
          t({
            message:
              "Provide liquidity for top rated new projects on Sui network in exchange for IDO tokens.",
          })
        ),
        i18n._(
          t({
            message:
              "Stake HEN tokens to earn additional rewards and IDOs allocation.",
          })
        ),
      ],
    },
    {
      label: i18n._(t({ message: "Money Market" })),
      image: (
        <Image
          src={imgMoneyMarket.src}
          alt=""
          mx={"auto"}
          width={{ base: "180px", md: "auto" }}
        />
      ),
      text: i18n._(
        t({ message: "Seamless lending and credit market on Sui network." })
      ),
      lists: [
        i18n._(
          t({
            message:
              "Borrow cryptocurrencies with no credit check and fast origination.",
          })
        ),
        i18n._(
          t({
            message:
              "Supply cryptocurrencies to earn a variable APY. Secured by over-collateralized assets.",
          })
        ),
      ],
    },
  ];
  return (
    <Box bg="white" mt={{ base: "-24" }} pt={{ base: "16" }} pb={8}>
      <Container
        pt={{
          base: "16",
          md: "18",
          lg: "24",
        }}
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
        }}
        pos="relative"
      >
        <Heading
          as={"h2"}
          textAlign="center"
          fontWeight="bold"
          mb={{ base: 4 }}
          fontSize={{ base: "3xl", md: "4xl", lg: "5xl" }}
          color={useColorModeValue("black", "black")}
        >
          {i18n._(t({ message: "Hentis Ecosystem" }))}
        </Heading>
        <Text
          fontSize={{ base: "lg", md: "md", lg: "lg" }}
          fontWeight="medium"
          textAlign="center"
          mb={16}
          mx={"auto"}
          maxWidth={{ base: "3xl" }}
          color={useColorModeValue("black", "black")}
        >
          {i18n._(
            t({
              message: `Hentis combines a suite of features that power the evolution of decentralized finance in a single platform on Sui network.`,
            })
          )}
        </Text>
        <Grid
          templateColumns={"repeat(3, 1fr)"}
          gap={{ base: 4, md: 12, lg: 24 }}
          alignItems="stretch"
        >
          {items.map((item, index) => (
            <GridItem key={index} colSpan={{ base: 3, md: 1 }}>
              <Card {...item} />
            </GridItem>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default EcoSystem;
