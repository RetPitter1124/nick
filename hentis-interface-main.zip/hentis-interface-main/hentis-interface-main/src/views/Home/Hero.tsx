import {
  Box,
  Button,
  chakra,
  Container,
  Grid,
  GridItem,
  Heading,
  HStack,
  Image,
  Link,
  Text,
  useColorModeValue,
  useDisclosure,
} from "@chakra-ui/react";
import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import NextLink from "next/link";
import imgSuiHentis from "../../assets/intro/sui-hentis.png";
import { useComingSoon } from "../../state/global/hooks";
import AnimateBox from "./AnimateBox";

const Hero = () => {
  const { i18n } = useLingui();
  const [isComingSoon, enableComingSoon] = useComingSoon();

  return (
    <Box background="linear-gradient(90deg, rgba(35, 20, 212, 0.1) 0%, rgba(255, 255, 255, 0.1) 33.71%, rgba(255, 255, 255, 0.1) 49.86%, rgba(255, 255, 255, 0.1) 58.71%, rgba(225, 53, 240, 0.1) 100%)">
      <Container
        pt={{
          base: "10",
          lg: "36",
        }}
        maxW={{
          base: "container.sm",
          md: "container.md",
          lg: "container.lg",
          xl: "container.xl",
          "2xl": "container.2xl",
        }}
      >
        <Grid templateColumns="repeat(9, 1fr)">
          <GridItem colSpan={{ base: 9, lg: 5 }}>
            <Heading
              as={"h1"}
              fontWeight="semibold"
              fontSize={{ base: "3xl", lg: "6xl" }}
              mb="1"
            >
              {i18n._(t({ message: "All in One Defi " }))}
              <Text
                as={"span"}
                bgGradient="linear(to-r, #2314D4, #E135F0)"
                sx={{
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                Sui
              </Text>
              te
            </Heading>
            <Text
              fontSize={{ base: "md", lg: "xl" }}
              color={useColorModeValue("gray.700", "gray.50")}
              fontWeight={500}
              mb="4"
            >
              {i18n._(
                t({
                  message:
                    "An entrance for efficient one-stop crypto asset trading, lending and investments solution on Sui network.",
                })
              )}
            </Text>
            {/* <Text
              fontSize={{ base: "md", lg: "xl" }}
              color={useColorModeValue("gray.700", "gray.50")}
            >
              <Text
                as={"span"}
                bgGradient="linear(to-r, #2314D4, #E135F0)"
                sx={{
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                HENTIS
              </Text>
              &nbsp;-&nbsp;
              {i18n._(
                t({
                  message: "Entrance to the Defi suite built on Sui",
                })
              )}
            </Text> */}
            <HStack mt={12} spacing={{ base: 6, lg: 12 }}>
              {/* <NextLink href={"/swap"}> */}
              <Button
                colorScheme={"brand"}
                variant="gradient"
                px={{ base: "10", lg: "16" }}
                py={{ base: "4", lg: "6" }}
                onClick={enableComingSoon}
              >
                {i18n._(
                  isComingSoon
                    ? t({ message: "Coming Soon" })
                    : t({ message: "Enter App" })
                )}
              </Button>
              {/* </NextLink> */}
              <Link href={"https://docs.hentis.one/"} isExternal>
                <Button
                  colorScheme={"white"}
                  variant="gradient"
                  px={{ base: "10", lg: "16" }}
                  py={{ base: "4", lg: "6" }}
                >
                  {i18n._(t({ message: "Read Docs" }))}
                </Button>
              </Link>
            </HStack>
          </GridItem>
          <GridItem colSpan={{ base: 9, lg: 4 }}>
            <AnimateBox
              mt={{ base: 0, lg: "-24" }}
              animate={{
                opacity: [0.5, 1],
                scale: [0.5, 1],
                translateX: [-800, 0],
                translateY: [100, -100, 0],
                rotate: [-360, 0],
              }}
              // @ts-ignore no problem in operation, although type error appears.
              transition={{
                duration: 1,
                ease: "easeInOut",
                // repeat: Infinity,
                // repeatType: "loop",
              }}
            >
              <Image src={imgSuiHentis.src} alt="" w="100%" />
            </AnimateBox>
          </GridItem>
        </Grid>
        <Grid templateColumns={"repeat(3, 1fr"}>
          <GridItem></GridItem>
        </Grid>
      </Container>
    </Box>
  );
};

export default Hero;
