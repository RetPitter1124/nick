import { t } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import type { NextPage } from "next";
import Head from "next/head";
import { useRouter } from "next/router";
import { useEffect } from "react";
import IntroLayout from "../Layouts/IntroLayout";
import About from "./About";
import EcoSystem from "./EcoSystem";
import Features from "./Features";
import GetStarted from "./GetStarted";
import Hero from "./Hero";
import KeyValues from "./KeyValues";
import Partners from "./Partners";
import Teams from "./Teams";
import Values from "./Values";

const Home: NextPage = () => {
  const { i18n } = useLingui();
  const router = useRouter();
  useEffect(() => {
    // router.push("/swap");
  }, []);
  return (
    <>
      <Head>
        <title>{i18n._(t({ message: "Hentis.One" }))}</title>
      </Head>
      <IntroLayout>
        <Hero />
        <KeyValues />
        <EcoSystem />
        {/* <Teams /> */}
        {/* <Values /> */}
        {/* <About /> */}
        {/* <Features /> */}
        <GetStarted />
        <Partners />
      </IntroLayout>
    </>
  );
};

export default Home;
